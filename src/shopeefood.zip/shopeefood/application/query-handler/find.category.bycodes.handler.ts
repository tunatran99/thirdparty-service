import { EventBus, IQueryHandler, QueryHandler } from '@nestjs/cqrs';
import { FindCategoryByCodesQuery } from '../query/find.category.bycodes.query';
import { Inject } from '@nestjs/common';
import { CategoryQueryImplement } from 'src/shopeefood/infratsructure/query/category.query.implement';

@QueryHandler(FindCategoryByCodesQuery)
export class FindCategoryByCodesQueryHandler implements IQueryHandler<FindCategoryByCodesQuery, void> {
  constructor(readonly eventBus: EventBus) {}

  @Inject()
  private readonly categoryQuery: CategoryQueryImplement;

  async execute(command: FindCategoryByCodesQuery): Promise<void> {
    const data = await this.categoryQuery.selectSomeRecords(command.id);
  }
}
